# Tay AI

Who is Tay? Tay is a AI made by SandBeap#4022 

Required:

- Latests Version Of Python *3.10*

After Installing Python:

- pip install speechRecognition
- pip install pyttsx3
- pip install pywhatkit
- pip install wikipedia
- pip install pyjokes
- pip install requests
- pip install pipwin
- pipwin install pyaudio

*COPY AND PASTE EACH COMMAND UP THERE!!*
*Make Sure You Configure config.py*
When you're done doing that you can run command prompt and direct it to the directory of were the files are and run the script with *py main.py*
If any problems please feel free to open a ISSUE or email me at **rahoom.ajeena@gmail.com** 

*Beta v0.1.25*

# Updates

Added Covid-19 cases [MAKE SURE TO CONFIGURE YOUR COUNTRY AT CONFIG.PY]

*NEW UPDATES ^^*

- Added Weather
- Added Time
- Added Exit
- Added Play Song
- Added Config.py
	
*OLD UPDATES ^^*
