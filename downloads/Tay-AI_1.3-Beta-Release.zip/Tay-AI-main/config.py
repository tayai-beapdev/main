## CONFIG.PY

location = 'Newmarket' # PUT YOU'RE CITY
countryName = 'Canada' # PUT YOU'RE COUNTRY
hour12 = 'false' # false = 24 hour clock, true = 12 hour clock [must be lower case] *SYNCS WITH PC SO PICK THE PC CLOCK TYPE*
voiceee = '0' # 0 = female, 1 = male